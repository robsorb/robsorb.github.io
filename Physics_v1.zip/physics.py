from __future__ import division

import math
from geometry import *
from colour import *

class Space(object):
	def __init__(self, cam, ts):
		self.camera = cam
		self.stepsize = ts
		self.objects = []
		self.pause = False
		
	def update(self):
		if not self.pause:
		
			if not self.pause: 
				for o in self.objects: o.update()

			for o in self.objects: o.collision()
				
			

	def create_polygon(self, loc, rot, vel, avel, mass, bounds):
		return self.Polygon(self, loc, rot, vel, avel, mass, bounds)

	
	class Polygon(object):
		def __init__(self, s, loc, rot, vel, avel, mass, bounds):
			self.s = s
			self.g = self.s.camera.g
			self.s.objects.append(self)
			self._loc = loc
			self._rot = rot
			self.vel = vel
			self.avel = avel
			self.mass = mass
			self.bounds = bounds
			self.volume = 0
			tr = triangulate(self.bounds); trp = []; c = com(tr)
			for t in tr:
				#trp.append(self.g.polygon(moveverts(t, vecscale(-1, c)),  self.s.camera.canvas, fill='red', outline='white'))
				self.volume += trisurf(t)
			self.density = self.mass/self.volume
			self.moi = moi(tr, self.density)
			
			self.bounds = moveverts(self.bounds, vecscale(-1, c))
			self.r = self.bounds[0].m
			for i in range(1, len(self.bounds)):
				self.r = max(self.bounds[i].m, self.r)
			order = vertorder(self.bounds)
			self.normals = []
			for i in range(-1,len(self.bounds)-1):
				self.normals.append(vecsub(self.bounds[i], self.bounds[i+1]).a+math.pi/2*order)
				
				
			#trp.append(self.g.circle(Vec(0,0), self.r, self.s.camera.canvas, fill='lime', layer=5))
			
			
			self.forces = []
			self.ft = []
			
		
		@property
		def loc(self):
			return self._loc
		@loc.setter
		def loc(self, v):
			self._loc = v
			
		@property
		def rot(self):
			return self._rot
		@rot.setter
		def rot(self, a):
			self._rot = a
			
		
		
		def collision(self):
			for o in self.s.objects:
				if o != self:
					r = self.r+self.vel.m/self.s.stepsize
					if vecsub(self.loc, o.loc).m < r+o.r+o.vel.m/self.s.stepsize:
						gbounds1 = transformverts(self.bounds, self.loc, self.rot, 1)
						gbounds2 = transformverts(o.bounds, o.loc, o.rot, 1)
						collisions = []
						for i in range(0, len(self.bounds)):
							if inside(gbounds1[i], gbounds2):
								i2 = i-1
								i3 = 0 if len(self.bounds)-1 <= i else i+1
								#self.s.camera.create_circle(gbounds1[i], 0.01, fill='lime')
								#self.s.camera.create_circle(gbounds1[i2], 0.01, fill='lime')
								#self.s.camera.create_circle(gbounds1[i3], 0.01, fill='lime')
								pd1 = None; pd2 = None; pd = None
								normals = [ n+o.rot for n in o.normals ]
								lines = []
								for j in range(-1, len(o.bounds)-1):
									for k in range(-1, len(self.bounds)-1):
										if intersect(gbounds1[k], gbounds1[k+1], gbounds2[j], gbounds2[j+1]):
											lines.append(j)
											break
								for l in lines:
									if pd == None:
										pd = vecdot(normals[l+1], vecsub(gbounds2[l], gbounds1[i]))
										cl = l
									else:
										if vecdot(normals[l+1], vecsub(gbounds2[l], gbounds1[i])) > 0 and vecdot(normals[l+1], vecsub(gbounds2[l], gbounds1[i])) < pd:
											pd = vecdot(normals[l+1], vecsub(gbounds2[l], gbounds1[i]))
											cl = l
								#self.s.pause=True
								#break
								if pd != None: collisions.append([pd, cl, i])
						
						#print len(collisions)
						if len(collisions) > 0:
							#self.s.pause = True
							collision = 0
							tpd = collisions[0][0]
							for i in range(1, len(collisions)):
								tpd += collisions[i][0]
								if collisions[i][0] > collisions[collision][0]:
									collision = i
							pd = collisions[collision][0]
							na = o.normals[collisions[collision][1]+1]+o.rot
							self.loc = vecsub(self.loc, Vec(m=1*-pd*(1-self.mass/(o.mass+self.mass)),a=na))
							o.loc = vecsub(o.loc, Vec(m=1*pd*(1-o.mass/(o.mass+self.mass)),a=na))
							gbounds3 = transformverts(self.bounds, self.loc, self.rot, 1)
							#print 1
							vel1 = self.vel
							vel2 = o.vel
							avel1 = self.avel
							avel2 = o.avel
							for i in range(0, len(collisions)):
								#print 2
								c = collisions[i]
								cp = gbounds3[c[2]]
								av1 = veccross(avel1, vecsub(cp, self.loc))
								v1 = vecadd(vel1, av1)
								av2 = veccross(avel2, vecsub(cp, o.loc))
								v2 = vecadd(vel2, av2)
								r1 = vecsub(cp, self.loc)
								r2 = vecsub(cp, o.loc)
								n = Vec(m=1, a=na)
								dv = vecsub(v1, v2)
			
								e = 0.1
								j = (-(1+e) * vecdot(dv, n))/(1/self.mass+1/o.mass+(veccross(r1, n)**2/self.moi)+(veccross(r2, n)**2/o.moi))	
								pdp = c[0]/tpd
								
								self.applyforce(cp, Vec(m=j*self.s.stepsize *pdp,a=n.a))
								o.applyforce(cp, Vec(m=-j*self.s.stepsize *pdp,a=n.a))
								np = Vec(m=1, a=n.a-math.pi/2)
								fc = 0.8
								dvp = vecdot(n.a-math.pi/2, dv)
												
								fr = j*fc*(dvp/abs(dvp))*min(1,abs(dvp/(j*fc/min(self.mass, o.mass))))*self.s.stepsize*pdp
								#fr = j*fc*dvp/abs(dvp)*pdp*self.s.stepsize
								#print j
								self.applyforce(cp, Vec(m=fr ,a=n.a+math.pi/2))
								o.applyforce(cp, Vec(m=-fr ,a=n.a+math.pi/2))
								
							
				
				
		def update(self):
			self.move(1)
			for f in self.ft: f.delete()
			self.ft = []
			gbounds = transformverts(self.bounds, self.loc, self.rot, 1)
			for i in range(-1,len(self.bounds)-1):
				self.s.camera.vector(Vec(m=0.3,a=self.normals[i+1]+self.rot), 0.1, fill='blue', loc=midpoint(gbounds[i],gbounds[i+1]), label=str(self)+'n'+str(i), style='line', layer=2)
			for f in self.forces:
				self.s.camera.vector(vecscale(0.2, f[1]), 0.05, fill='aqua', loc=f[0], label=str(self)+'f'+str(f), style='arrow', layer=1)
				pass
			#print 1
			self.s.camera.outline(gbounds, 0.01, fill='white', label=str(self)+"b")
			self.forces = []
		
		def move(self, t):
			self.loc = vecadd(self.loc, vecscale(1/self.s.stepsize*t, self.vel))
			self.rot += self.avel/self.s.stepsize*t

		def applyforce(self, v, f):
			self.vel = vecadd(self.vel, vecscale(1/self.mass/self.s.stepsize, f))
			self.applytorque(veccross(vecsub(v, self.loc), f))
			self.forces.append([v, f])

		def applytorque(self, t):
			self.avel += t/self.moi/self.s.stepsize
			#print self.avel
		
		
