import colorsys

def rgb(r, g, b):
	col = [r,g,b]
	ch = "#"
	for c in col:
		if (len("%x"%c) == 1):
			ch = ch + "0%x"%c
		else:
			ch = ch + "%x"%c
	return ch

def hsv(h,s,v):
	rgb1 = colorsys.hsv_to_rgb(h,s,v)
	return rgb(rgb1[0]*255,rgb1[1]*255,rgb1[2]*255)
