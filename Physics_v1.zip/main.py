# -*- coding: utf-8 -*-
from __future__ import division

from Tkinter import*
import math
import time
import os
import random
import colorsys
import copy
import pickle
import glob
import graphics
from geometry import *
from loop import *
import physics

os.system('xset r off')
#___________________________ Variables ___________________________

#net = Neuralnet([[Neuron([1,3])],
#		 [Neuron([2])]])
#print net.forward([1,-0.5])

#v#

mainloop = True

FPS = 24
WIDTH = 1000
HEIGHT = WIDTH/1.5


worldtime = 0
timewarp = 1

k_shift = False
k_up = False
k_down = False
k_left = False
k_right = False
k_ctrl = False

cammode = 0

mouse_x, mouse_y = 0, 0
mouse_l, mouse_r, mouse_m = False, False, False
clickmode = 0

updatables = []
physicals = []
graphicals = []
celestials = []
clickables = []
plants = []
leaves = []
seeds = []
cameras = []
selectedcam = None
renderlayers = []

saveb = False

window = Tk()
window.geometry(str(int(round(WIDTH)))+"x"+str(int(round(HEIGHT))))
canvas = Canvas(window, width=WIDTH, height=HEIGHT)


# physical constants:
G = 6.674e-11 #N*m^2kg^-2
waterdensity = 998.2071 #kgm^-3
sugardensity = 1540.0 #kgm^-3
wooddensity = 1500.0

plantgrowthrate = 0.01

planetradius = 0 #m
gravacc = 0 #ms^-2
planetmass = gravacc*math.pow(planetradius,2)/G #kg

pause = False
#graphics = True
drawwind = False
drawar = False




field = 25

mLog = True

saveN = len(glob.glob("saves/*"))
#___________________________ Functions ___________________________


def oper(x, o, y, v):
	if o == '+': return x+var(y, v)
	elif o == '-': return x-var(y, v)
	elif o == '*': return x*var(y, v)
	elif o == '/': return x/var(y, v)
	elif o == '%': return x%var(y, v)
	elif o == 'p': return pow(x, var(y, v))
	elif o == 'r': return pow(x, 1/var(y, v))
	elif o == 'R': return round(x, int(var(y, v)))
	elif o == 'x': return max(x, var(y, v))
	elif o == 'n': return min(x, var(y, v))
	elif o == 'e': return x*pow(10, var(y, v))


def writelog(s):
	global saveN
	global log
	if not os.path.exists('log/save'+str(saveN)):
		os.makedirs('log/save'+str(saveN))
	
	if not os.path.exists('log/save'+str(saveN)+'/connections('+str(len(glob.glob('log/save'+str(saveN))))+').log'):
		log = open('log/save'+str(saveN)+'/connections('+str(len(glob.glob('log/save'+str(saveN))))+').log', 'a')
		
		log.close()

		
	
	
	if os.path.getsize('log/save'+str(saveN)+'/connections('+str(len(glob.glob('log/save'+str(saveN))))+').log') > 5000000:
		log = open('log/save'+str(saveN)+'/connections('+str(len(glob.glob('log/save'+str(saveN)))+1)+').log', 'a')
		log.write(str(s)+'\n')
		log.close()
	else:
		log = open('log/save'+str(saveN)+'/connections('+str(len(glob.glob('log/save'+str(saveN))))+').log', 'a')
		log.write(str(s)+'\n')
		log.close()

def save():
	print glob.glob("saves/*")
	global worldtime, updatables, physicals, graphicals, celestials, clickables, plants, leaves, seeds, camera, mainloop
	
	pickle.dump((worldtime, updatables, physicals, graphicals, celestials, clickables, plants, leaves, seeds, camera), open( "saves/save"+str(len(glob.glob("saves/*")))+".dat", "wb" ))
	
	
def load(n):

	global saveN, worldtime, updatables, physicals, graphicals, celestials, clickables, plants, leaves, seeds, camera
	saveN = n
	worldtime, updatables, physicals, graphicals, celestials, clickables, plants, leaves, seeds, camera = pickle.load( open( "saves/save"+str(n)+".dat", "rb" ) )
	for p in plants:
		p.name = genname(p.DNA)
	
	
def atmdensity(x,y):
	dvec = pol(planet.x-x,planet.y-y)
	
	return max(0,pow(1-(dvec[0]-planet.r)/planet.atm,3)*1.225)



def between(x,x1,x2):
	return (x >= x1 and x <= x2) or (x <= x1 and x >= x2)

def celestialmass(g, r):
	global G
	return g*pow(r,2)/G #kg


def rgb(r, g, b):
	col = [r,g,b]
	ch = "#"
	for c in col:
		if (len("%x"%c) == 1):
			ch = ch + "0%x"%c
		else:
			ch = ch + "%x"%c
	return ch

def hsv(h,s,v):
	rgb1 = colorsys.hsv_to_rgb(h,s,v)
	return rgb(rgb1[0]*255,rgb1[1]*255,rgb1[2]*255)



def tick(fps=60):
	global _tick2_frame,_tick2_fps,_tick2_t0
	n=_tick2_fps/fps
	_tick2_frame+=n
	while n>0: n-=1
	if time.time()-_tick2_t0>1:
		_tick2_t0=time.time()
		_tick2_fps=_tick2_frame
		_tick2_frame=0



def keydown(event):
	#print event.keycode
	global cam_y, cam_x, cam_rot, scale, k_w, pause, k_ctrl, k_shift, FPS, k_up, k_down, k_left, k_right, timewarp, graphics, saveb, cammode, drawwind, drawar
	if event.keycode == 50: k_shift = True
	if event.keycode == 37: k_ctrl = True
def keyup(event):

	global cam_y, cam_x, cam_rot, scale, k_w, k_ctrl, k_shift, k_up, k_down, k_left, k_right, graphicals, physicals, plants, leaves, seeds
	if event.keycode == 50: k_shift = False
	if event.keycode == 37: k_ctrl = False



def on_closing():
	#save()
	os.system('xset r on')
	print 2
	window.destroy()
	
def motion(event):
	global mouse_x, mouse_y, selectedcam, k_ctrl, WIDTH, HEIGHT
	if mouse_m:
		if k_shift:
			if selectedcam != None:
				a = (orientation(event.x-WIDTH/2, event.y-HEIGHT/2))-(orientation(mouse_x-WIDTH/2, mouse_y-HEIGHT/2))
				selectedcam.rot += a
		elif k_ctrl:
			if selectedcam != None:
				s = (hyp(event.x-WIDTH/2, event.y-HEIGHT/2))-(hyp(mouse_x-WIDTH/2, mouse_y-HEIGHT/2))
				selectedcam.scale *= 1/(1+s/50)
		else:
			if selectedcam != None:
				v = Vec(mouse_x-event.x, mouse_y-event.y)
				selectedcam.loc = vecadd(selectedcam.loc, vecscale(1/selectedcam.scale, Vec(m=v.m, a=v.a-selectedcam.rot)))
				#print selectedcam
	mouse_x, mouse_y = event.x, event.y

def mousewheelup(event):
	global k_ctrl, k_shift
	
	if k_ctrl and k_shift:
		if selectedcam != None: selectedcam.rot += math.pi/16
	elif k_shift:
		if selectedcam != None: 
			v = Vec(0, HEIGHT/32)
			selectedcam.loc = vecadd(selectedcam.loc, vecscale(1/selectedcam.scale, Vec(m=v.m, a=v.a-selectedcam.rot)))
	elif k_ctrl:
		if selectedcam != None: 
			v = Vec(WIDTH/32, 0)
			selectedcam.loc = vecadd(selectedcam.loc, vecscale(1/selectedcam.scale, Vec(m=v.m, a=v.a-selectedcam.rot)))
	else:
		if selectedcam != None: selectedcam.scale *= 1.1

def mousewheeldown(event):
	global k_ctrl, k_shift
	if k_ctrl and k_shift:
		if selectedcam != None: selectedcam.rot -= math.pi/16
	elif k_shift:
		if selectedcam != None: 
			v = Vec(0, -HEIGHT/32)
			selectedcam.loc = vecadd(selectedcam.loc, vecscale(1/selectedcam.scale, Vec(m=v.m, a=v.a-selectedcam.rot)))
	elif k_ctrl:
		if selectedcam != None: 
			v = Vec(-WIDTH/32, 0)
			selectedcam.loc = vecadd(selectedcam.loc, vecscale(1/selectedcam.scale, Vec(m=v.m, a=v.a-selectedcam.rot)))
	else:
		if selectedcam != None: selectedcam.scale /= 1.1

def middlebuttondown(event):
	global mouse_m, k_ctrl, WIDTH, HEIGHT
	mouse_m = True
	
def middlebuttonup(event):
	global mouse_m, k_ctrl
	mouse_m = False
force = []
def leftbuttondown(event):
	global mouse_l, cam, mouse_x, mouse_y, s, force
	mouse_l = True
	ic = cam.internalcoords(Vec(mouse_x, mouse_y))
	for o in s.objects:
		if inside(ic, transformverts(o.bounds, o.loc, o.rot, 1)):
			v = vecsub(ic, o.loc)
			force = [o, Vec(m=v.m,a=v.a-o.rot)]

def leftbuttonup(event):
	global mouse_l, force
	mouse_l = False
	force = []
#___________________________ Classes ___________________________




window.protocol("WM_DELETE_WINDOW", on_closing)
window.bind('<Motion>', motion)

window.bind("<Key>", keydown)
window.bind("<KeyRelease>", keyup)
window.bind("<Button-4>", mousewheelup)
window.bind("<Button-5>", mousewheeldown)
window.bind("<Button-2>", middlebuttondown)
window.bind("<ButtonRelease-2>", middlebuttonup) 
canvas.bind("<Button-1>", leftbuttondown)
canvas.bind("<ButtonRelease-1>", leftbuttonup)
#canvas.bind("<Double-Button>", doublebutton)

canvas.pack()

canvas.configure(background="black")


l = Loop()
g = graphics.Graphics(canvas)
cam = g.camera(scale=10)

s = physics.Space(cam, 60)



o1 = s.create_polygon(Vec(2,0), 0, Vec(0,0), 0, 1, vectorverts(0,0.2,1,0,2,1,1,2,0,1.8,0.5,1.8,1,1.5,-0.2,1,1,0.5,0.5,0.2))
o2 = s.create_polygon(Vec(-2,0), 0, Vec(0,0), 0, 1, ngon(1,24))#vectorverts(0,0,0,-2,1,-1))
o3 = s.create_polygon(Vec(0,10), 0, Vec(0,0), 0, 1e12, vectorverts(0,0,50,0,50,5,0,5))
o4 = s.create_polygon(Vec(-4,0), -math.pi/2, Vec(0,0), 0, 1, vectorverts(0,0,0,-2,1,-1))

selectedcam = cam


'''while mainloop:
	tick(FPS)
	

	s.update()

	g.render()
	
	WIDTH = window.winfo_width()
	HEIGHT = window.winfo_height()
	canvas.config(width=WIDTH,height=HEIGHT)
	window.update()
	canvas.update()'''



def render():
	global t, q, T, cam
	#q.loc = cam.internalcoords(Vec(mouse_x, mouse_y))
	g.canvas["width"] = window.winfo_width()
	g.canvas["height"] = window.winfo_height()
	g.render()
	window.update()
	canvas.update()
q=0
def piter():
	global o1, o2, force, mouse_l, cam, g, q
	#print mouse_l
	#print force
	q +=1 
	
	if mouse_l:
		if len(force) > 0:
			v1 = transform(force[1], force[0].loc, force[0].rot, 1)
			force[0].applyforce(v1, vecscale(5,vecsub(cam.internalcoords(Vec(mouse_x, mouse_y)), v1)))
	o1.applyforce(o1.loc, Vec(0,9.81*o1.mass))
	o2.applyforce(o2.loc, Vec(0,9.81*o2.mass))
	o4.applyforce(o4.loc, Vec(0,9.81*o4.mass))
	s.update()
	pass

l.create_loop(24, render)
l.create_loop(60, piter)
l.startloop()


