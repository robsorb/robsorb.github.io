import math

def hyp(x,y):
	return math.sqrt(x*x+y*y)

def pol(x,y=0):
	if type(x) is tuple:
		x, y = x 
	return (math.sqrt(x**2 + y**2), math.atan2(y, x))

def rec(m,a=0):
	if type(m) is tuple:
		m, a = m
	return (m*math.cos(a), m*math.sin(a))



def inside(v, verts):
	ins = False
	x, y = v.x, v.y
	for v in range(-1,len(verts)-1):
		x1, y1 = verts[v].x, verts[v].y
		x2, y2 = verts[v+1].x, verts[v+1].y
		if (y > y1) != (y > y2): 
			if (x1 != x2):
				a = findslope(x1, y1, x2, y2)
				b = findstart(x1,y1,a)
				cx = (y-b)/a
			else:
				cx = x1
			if (x > cx): ins = not ins
	return ins

def findslope(x1,y1,x2,y2):
	x1,y1,x2,y2 = float(x1), float(y1), float(x2), float(y2)
	if x1 > x2:
		return (y1-y2)/(x1-x2)
	else:
		return (y2-y1)/(x2-x1)

def findstart(x,y,a):
	return y-a*x
	
def orientation(x, y):
	return math.atan2(y, x)

def line(p1, p2):
	A = (p1.y - p2.y)
	B = (p2.x - p1.x)
	C = (p1.x*p2.y - p2.x*p1.y)
	return A, B, -C

def intersection(a, b, c, d):
	L1 = line(a, b)
	L2 = line(c, d)
	D  = L1[0] * L2[1] - L1[1] * L2[0]
	Dx = L1[2] * L2[1] - L1[1] * L2[2]
	Dy = L1[0] * L2[2] - L1[2] * L2[0]
	if D != 0:
		x = Dx / D
		y = Dy / D
		return Vec(x, y)
	else:
		return False


def ccw(A,B,C):
	return (C.y-A.y) * (B.x-A.x) > (B.y-A.y) * (C.x-A.x)

def intersect(A,B,C,D):
	return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)

def intersectpoly(A,B,verts, q, qq):

	intersections = 0
	for i in range(-1, len(verts)-1):
		if i != q and i != qq and i+1 != q and i+1 != qq and len(verts) > 4:
			if intersect(A, B, verts[i], verts[i+1]): intersections += 1
	return intersections

def ngon(r, n):
	o = []
	for i in range(0,n):
		o.append(Vec(m=r, a=math.pi/n*i*2))
	return o



def copyverts(v):
	verts = []
	for ver in v:
		verts.append(ver.duplicate())
	return verts

def triangulate(v):

	

	verts = []
	for vert in v:
		verts.append(vert.duplicate())
	o = []
	i = 0
	while len(verts) > 3:
		if i >= len(verts): i = 0
		a = verts[i-1]; b = verts[i]
		c = verts[0] if i == len(verts)-1 else verts[i+1]
		q = i-1
		qq = 0 if i == len(verts)-1 else i+1
		
		#if not intersectpoly(a, c, verts, q, qq) <= 0:
			#print a.rec(), c.rec(), intersectpoly(a, c, verts, q, qq), i, q, qq
		if intersectpoly(a, c, verts, q, qq) <= 0 and inside(midpoint(a,c),verts):
			
			o.append([a, b, c])
			verts.pop(i)
			
		else:
			i += 1
		
	
	o.append(verts)

	return o

def tricom(t):
	d = vecscale(0.5, vecadd(t[0], t[1]))
	x = (d.x-t[2].x)*(2/3.0)+t[2].x;
	y = (d.y-t[2].y)*(2/3.0)+t[2].y;
	return Vec(x, y)


def trisurf(t):
	a = t[0]; b = t[1]; c = t[2]
	C = vecsub(a, b).m; B = vecsub(a, c).m; A = vecsub(c, b).m
	s = (A + B + C) / 2.0
	return (s*(s-A)*(s-B)*(s-C)) ** 0.5

def com(tr):
	xsum, ysum, ssum = 0, 0, 0
	for t in tr:
		p = tricom(t)
		surf = trisurf(t)
		xsum += p.x*surf; ysum += p.y*surf
		ssum += surf
	return Vec(xsum/float(ssum), ysum/float(ssum))

def angle(a, b, c):
	a1 = math.atan2(a.x-b.x, a.y-b.y)
	a2 = math.atan2(a.x-c.x, a.y-c.y)
	da = abs(a1-a2)
	return min(math.pi*2-da, da) 

def trialt(tr):
	return hyp(tr[0].x-tr[2].x,tr[0].y-tr[2].y)*math.sin(angle(tr[0], tr[1], tr[2]))

def triI(tr):
	
	a = 0
	t = []
	for i in range(0,len(tr)):	
		if angle(tr[i],tr[i-1],tr[i-2]) > a:
			a = angle(tr[i],tr[i-1],tr[i-2])
			t = [tr[i-2],tr[i-1],tr[i]]
	h = trialt(t)
	b = hyp(t[0].x-t[1].x,t[0].y-t[1].y)
	a = hyp(t[0].x-t[2].x,t[0].y-t[2].y)*math.cos(angle(t[0],t[1],t[2]))
	return (b**3*h-b**2*h*a+b*h*a**2+b*h**3)/36

def moi(tr, d):
	o = 0
	for t in tr:
		i = triI(t)
		r = tricom(t).m
		m = trisurf(t)*d
		o += m*r**2+i
		
	return o

def supportpoint(v1, n, v2):
	j = 0
	for i in range(1, len(v2)):
		if vecdot(n+math.pi, vecsub(v2[i], v1)) > vecdot(n+math.pi, vecsub(v2[j], v1)): j = i
	return j

def vertorder(verts):
	o = 0
	for i in range(-1, len(verts)-1):
		o += (verts[i].x-verts[i+1].x)*(verts[i].y+verts[i+1].y)
	return -1 if o < 0  else 1
#vectors

def vecadd(a, b):
	return Vec(x=a.x+b.x, y=a.y+b.y)

def vecsub(a, b):
	return Vec(x=a.x-b.x, y=a.y-b.y)

def vecdot(a, b):
	if type(a) is int or type(a) is float:
		x, y = rec(1, a)
		return x*b.x+y*b.y
	elif type(b) is int or type(b) is float:
		x, y = rec(1, b)
		return a.x*x+a.y*y
	else:
		return a.x*b.x+a.y*b.y

def veccross(a, b):
	if type(a) is int or type(a) is float:
		x, y = rec(1, a)
		return Vec(x=-a*b.y, y=a*b.x)
	elif type(b) is int or type(b) is float:
		return b*a.y-b*a.x
	else:
		return a.x*b.y-a.y*b.x

def vecscale(a, b):
	if type(a) is int or type(a) is float:
		return Vec(x=a*b.x, y=a*b.y)
	else:
		return Vec(x=a.x*b, y=a.y*b)

def midpoint(a, b):
	return vecscale(0.5, vecadd(a, b))

class Vec:
	def __init__(self, *args, **kwargs):
		if len(kwargs.keys()) > 0:
			if kwargs.keys()[0] == 'x' or kwargs.keys()[0] == 'y':
				self.x = kwargs['x']; self.y = kwargs['y']
			else:
				self.x = kwargs['m']*math.cos(kwargs['a']); self.y = kwargs['m']*math.sin(kwargs['a'])
		if len(args) > 0:
			self.x, self.y = args
	@property
	def m(self):
		return math.sqrt(self.x**2+self.y**2)
	@property
	def a(self):
		return math.atan2(self.y, self.x)	
	def rec(self):
		return (self.x, self.y)
	def pol(self):
		return (self.m, self.a)
	def duplicate(self):
		return Vec(self.x, self.y)
def listverts(*args):
	
	if type(args[0]) is int or type(args[0]) is float:
		o = []
		for i in range(0, len(args)//2):
			o.append([args[i*2], args[i*2+1]])
		return o
	elif type(args[0]) is list:
		o = []
		for v in args[0]:
			o.append(list(v.rec()))
		return o

def vectorverts(*args):
	if type(args[0]) is float or type(args[0]) is int:
		o = []
		for i in range(0, len(args)//2):
			o.append(Vec(x=args[i*2], y=args[1+i*2]))
		return o
	elif type(args[0]) is list:
		o = []
		for v in args:
			o.append(Vec(x=v[0], y=v[1]))
		return o

def rotate(v1, v2, a):
	d = vecsub(v1, v2)
	return vecadd(Vec(m=d.m, a=d.a+a), v2)
		
def rotateverts(verts, v2, a):
	verts = verts[:]
	for i in range(0, len(verts)):
		verts[i] = rotate(verts[i], v2, a)
	return verts

def scaleverts(verts, s):
	verts = verts[:]
	for i in range(0, len(verts)):
		verts[i] = vecscale(verts[i], s)
	return verts

def moveverts(verts, v):
	verts = verts[:]
	for i in range(0, len(verts)):
		verts[i] = vecadd(verts[i], v)
	return verts

def transformverts(verts, v, a, s):
	return moveverts(scaleverts(rotateverts(verts, Vec(0, 0), a), s), v)

def transform(v1, v2, a, s):	
	return vecadd(vecscale(rotate(v1, Vec(0, 0), a), s), v2)
