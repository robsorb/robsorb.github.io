from __future__ import division
import time

_tick2_frame=0
_tick2_fps=20000000 # real raw FPS
_tick2_t0=time.time()

def tick(fps=60):
	global _tick2_frame,_tick2_fps,_tick2_t0
	n=_tick2_fps/fps
	_tick2_frame+=n
	while n>0: n-=1
	if time.time()-_tick2_t0>1:
		_tick2_t0=time.time()
		_tick2_fps=_tick2_frame
		_tick2_frame=0


class Loop:
	def __init__(self):
		self.loops = []
		
	class Loop:
		def __init__(self, outer, fps, func):
			self.outer = outer
			self.outer.loops.append(self)
			self.fps = fps
			self.loop = func
			self.t = 0
		
		def _loop(self, fps):
			self.t += 1/fps
			if self.t >= 1/self.fps:
				self.loop()
				self.t = self.t-1/self.fps
	
	def create_loop(self, fps, func):
		return self.Loop(self, fps, func)

	def startloop(self):
		while True:
			fps = 1 
			for l in self.loops:
				fps = max(fps, l.fps)		
			tick(fps)
			for l in self.loops:
				l._loop(fps)
			

