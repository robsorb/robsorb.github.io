from __future__ import division

from geometry import *
from Tkinter import*

class Graphics(object):
	def __init__(self, can):
		self.layers = []
		self.labels = []
		self.canvas = can
	
	def render(self):
		self.canvas.delete(ALL)
		#print self.layers
		if len(self.layers) > 0:
			for i in range(1,len(self.layers)+1):
				for j in range(0, len(self.layers[-i])):
					self.layers[-i][j].render()
					
		self.layers = []; self.labels = []
		
	class Shape(object):
		def __init__(self, g, **kwargs):
			self.g = g
			self.loc = Vec(0, 0); self.rot = 0; self.scale = 1; self.layer = 5; self.label = None; self.style = None
			if 'loc' in kwargs.keys():
				self.loc = kwargs['loc']; kwargs.pop('loc')
			if 'rot' in kwargs.keys():
				self.rot = kwargs['rot']; kwargs.pop('rot')
			if 'scale' in kwargs.keys():
				self.scale = kwargs['scale']; kwargs.pop('scale')
			if 'layer' in kwargs.keys():
				self.layer = kwargs['layer']; kwargs.pop('layer')
			if 'label' in kwargs.keys():
				self.label = kwargs['label']; kwargs.pop('label')
			if 'style' in kwargs.keys():
				self.style = kwargs['style']; kwargs.pop('style')
			if self.label == None:
				while len(self.g.layers)-1 < self.layer: 
					self.g.layers.append([])
				self.g.layers[self.layer].append(self)
			elif not self.label in self.g.labels:
				while len(self.g.layers)-1 < self.layer: 
					self.g.layers.append([])
				self.g.layers[self.layer].append(self); self.g.labels.append(self.label)
			self.kwargs = kwargs
	class Polygon(Shape):
		def __init__(self, g, v, **kwargs):
			self.vertices = v
			g.Shape.__init__(self, g, **kwargs)
			
		def render(self):
			self.g.canvas.create_polygon(listverts(transformverts(self.vertices, self.loc, self.rot, self.scale)), **self.kwargs)

	class Circle(Shape):
		def __init__(self, g, r, **kwargs):
			self.r = r
			g.Shape.__init__(self, g, **kwargs)
			
		def render(self):
			r1, r2 = transform(Vec(-self.r, -self.r), self.loc, 0, self.scale), transform(Vec(self.r, self.r), self.loc, 0, self.scale)
			self.g.canvas.create_oval(r1.x, r1.y, r2.x, r2.y, **self.kwargs)
	
	class Line(Shape):
		def __init__(self, g, s, e, w, **kwargs):
			self.start = s
			self.end = e
			self.w = w
			g.Shape.__init__(self, g, **kwargs)
		def render(self):
			start = transform(self.start, self.loc, self.rot, self.scale)
			end = transform(self.end, self.loc, self.rot, self.scale)
			w = self.w*self.scale
			self.g.canvas.create_line(start.x, start.y, end.x, end.y, width=w, **self.kwargs)
	
	class Vector(Shape):
		def __init__(self, g, v, w, **kwargs):
			self.vec = v
			self.w = w
			g.Shape.__init__(self, g, **kwargs)
		def render(self):
			if self.style == None or self.style == 'triangular':
				self.g.canvas.create_polygon(listverts(transformverts([Vec(0, self.w/2), Vec(0, -self.w/2), Vec(self.vec.m, 0)], self.loc, self.vec.a+self.rot, self.scale)), **self.kwargs)
			if self.style == 'arrow':
				if self.vec.m > self.w*2:
					self.g.canvas.create_polygon(listverts(transformverts([Vec(self.vec.m-self.w, self.w/2), Vec(self.vec.m-self.w, -self.w/2), Vec(self.vec.m, 0)], self.loc, self.vec.a+self.rot, self.scale)), **self.kwargs)
					e = transform(Vec(m=self.vec.m-self.w/2,a=self.vec.a), self.loc, self.rot, self.scale)
					self.g.canvas.create_line(self.loc.x,self.loc.y,e.x,e.y,width=self.w/3*self.scale,**self.kwargs)
					r1 = transform(Vec(-self.w/2, -self.w/2), self.loc, 0, self.scale); r2 = transform(Vec(self.w/2, self.w/2), self.loc, 0, self.scale)
					self.g.canvas.create_oval(r1.x,r1.y,r2.x,r2.y,width=0,**self.kwargs)
			if self.style == 'line':
				e = transform(self.vec,self.loc,self.rot,self.scale)
				w1 = transform(Vec(0,self.w/2),self.loc,self.rot+self.vec.a,self.scale); w2 = transform(Vec(0,-self.w/2),self.loc,self.rot+self.vec.a,self.scale)
				self.g.canvas.create_line(self.loc.x,self.loc.y,e.x,e.y,width=self.w/10*self.scale,**self.kwargs)
				self.g.canvas.create_line(w1.x,w1.y,w2.x,w2.y,width=self.w/5*self.scale,**self.kwargs)
	
	class Outline(Shape):
		def __init__(self, g, v, w, **kwargs):
			self.vertices = v
			self.w = w
			g.Shape.__init__(self, g, **kwargs)
		def render(self):
			for i in range(-1, len(self.vertices)-1):
				s = transform(self.vertices[i], self.loc, self.rot, self.scale); e = transform(self.vertices[i+1], self.loc, self.rot, self.scale)
				self.g.canvas.create_line(s.x, s.y, e.x, e.y, width=self.w*self.scale, **self.kwargs)

	class Camera(object):
		def __init__(self, g, **kwargs):
			self.g = g
			self.loc = Vec(0, 0); self.rot = 0; self.scale = 1
			if 'loc' in kwargs.keys():
				self.loc = kwargs['loc']; kwargs.pop('loc')
			if 'rot' in kwargs.keys():
				self.rot = kwargs['rot']; kwargs.pop('rot')
			if 'scale' in kwargs.keys():
				self.scale = kwargs['scale']; kwargs.pop('scale')
		def dispcoords(self, v):
			v = v.duplicate()
			v2 = vecsub(vecscale(self.scale, v), vecscale(self.scale, self.loc))
			return vecadd(Vec(float(self.g.canvas['width'])/2, float(self.g.canvas['height'])/2), Vec(m=v2.m, a=v2.a+self.rot))
		def internalcoords(self, v):
			v = v.duplicate()
			v = vecsub(v, Vec(float(self.g.canvas['width'])/2, float(self.g.canvas['height'])/2))
			return vecadd(Vec(m=v.m/self.scale, a=v.a-self.rot), self.loc)
		
		def tocam(self, s):
			s.loc = self.dispcoords(s.loc)
			s.rot += self.rot
			s.scale *= self.scale	

		def polygon(self, *args, **kwargs):
			self.tocam(self.g.polygon(*args, **kwargs))
		def circle(self, *args, **kwargs):
			self.tocam(self.g.circle(*args, **kwargs))
		def line(self, *args, **kwargs):
			self.tocam(self.g.line(*args, **kwargs))	
		def vector(self, *args, **kwargs):
			self.tocam(self.g.vector(*args, **kwargs))
		def outline(self, *args, **kwargs):
			self.tocam(self.g.outline(*args, **kwargs))

	def camera(self, *args, **kwargs):
		return self.Camera(self, *args, **kwargs)
	def polygon(self, *args, **kwargs):
		return self.Polygon(self, *args, **kwargs)
	def circle(self, *args, **kwargs):
		return self.Circle(self, *args, **kwargs)
	def line(self, *args, **kwargs):
		return self.Line(self, *args, **kwargs)
	def vector(self, *args, **kwargs):
		return self.Vector(self, *args, **kwargs)
	def outline(self, *args, **kwargs):
		return self.Outline(self, *args, **kwargs)
